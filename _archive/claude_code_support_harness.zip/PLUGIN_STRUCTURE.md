# Claude Code Plugin: <PLUGIN_NAME>

version: 0.1
owner: <team or individual>

## Included Components
### Skills
- <skill_name>
- <skill_name>

### Agents
- <agent_name>
- <agent_name>

### MCP Tools
- <tool_name>

### Slash Commands
- </command> — description

## Installation
```bash
claude plugins install <plugin-name>
```

## Default Behavior
What Claude does immediately after plugin activation.

## Optional Features
Components that can be toggled on/off.

## Compatibility
- Claude Code version
- OS assumptions
- Repo types

## Governance
- Change approval process
- Versioning rules
- Rollback strategy
