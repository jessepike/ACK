# Dependencies: IPE MVP

---
status: "Final"
created: 2025-01-01
stage: "environment"
---

## Core Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| next | ^14.2.0 | Framework |
| react | ^18.2.0 | UI library |
| react-dom | ^18.2.0 | DOM renderer |
| @tiptap/react | ^2.4.0 | Editor bindings |
| @tiptap/starter-kit | ^2.4.0 | Editor extensions |
| @tiptap/extension-placeholder | ^2.4.0 | Placeholder |
| @tiptap/pm | ^2.4.0 | ProseMirror |
| @supabase/supabase-js | ^2.43.0 | Database client |
| @supabase/ssr | ^0.3.0 | SSR helpers |
| @anthropic-ai/sdk | ^0.24.0 | Claude API |
| tailwindcss | ^3.4.0 | Styling |
| autoprefixer | ^10.4.0 | CSS prefixes |
| postcss | ^8.4.0 | CSS processing |
| clsx | ^2.1.0 | Class utilities |
| tailwind-merge | ^2.3.0 | Merge classes |

## Dev Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| typescript | ^5.4.0 | Types |
| @types/react | ^18.2.0 | React types |
| @types/react-dom | ^18.2.0 | DOM types |
| @types/node | ^20.12.0 | Node types |
| eslint | ^8.57.0 | Linting |
| eslint-config-next | ^14.2.0 | Next rules |
| prettier | ^3.2.0 | Formatting |
| prettier-plugin-tailwindcss | ^0.5.0 | Tailwind sort |

## package.json

```json
{
  "name": "ipe",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint",
    "format": "prettier --write .",
    "typecheck": "tsc --noEmit"
  },
  "dependencies": {
    "@anthropic-ai/sdk": "^0.24.0",
    "@supabase/ssr": "^0.3.0",
    "@supabase/supabase-js": "^2.43.0",
    "@tiptap/extension-placeholder": "^2.4.0",
    "@tiptap/pm": "^2.4.0",
    "@tiptap/react": "^2.4.0",
    "@tiptap/starter-kit": "^2.4.0",
    "autoprefixer": "^10.4.0",
    "clsx": "^2.1.0",
    "next": "^14.2.0",
    "postcss": "^8.4.0",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "tailwind-merge": "^2.3.0",
    "tailwindcss": "^3.4.0"
  },
  "devDependencies": {
    "@types/node": "^20.12.0",
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0",
    "eslint": "^8.57.0",
    "eslint-config-next": "^14.2.0",
    "prettier": "^3.2.0",
    "prettier-plugin-tailwindcss": "^0.5.0",
    "typescript": "^5.4.0"
  },
  "engines": {
    "node": ">=20.0.0"
  }
}
```

## NOT in MVP

- zustand/redux (React state sufficient)
- prisma (direct Supabase simpler)
- zod (minimal validation needed)
- react-query (Server Components)
- jest/vitest (manual testing)
