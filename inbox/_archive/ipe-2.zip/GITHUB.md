---
doc_id: "domain-004"
slug: "github-domain"
title: "GitHub Domain Package"
type: "research_note"
tier: "tier1"
status: "active"
authority: "binding"
version: "0.1.0"
review_status: "draft"
created: "2026-01-02"
updated: "2026-01-02"
owner: "human"
depends_on: []
---

# GitHub Domain Package

Complete domain package for GitHub operations.

## Tier

**Global** — Every project uses GitHub.

## Package Contents

| Primitive | File | Purpose |
|-----------|------|---------|
| Agent | `agents/github-expert.md` | GitHub platform expertise |
| Skill | `skills/github/SKILL.md` | Procedural workflows |
| Tool | `tools/github.md` | MCP + CLI integration |
| Command | `commands/github-debug.md` | Debug GitHub issues |

## When to Use

- Repository setup and configuration
- Pull request workflows
- Issue management
- GitHub Actions CI/CD
- API operations

## Key Capabilities

### Via MCP
- List/query repos, PRs, issues
- Create PRs and issues
- Read file contents from repos
- Bulk operations

### Via CLI
- Interactive operations
- Complex PR creation
- Workflow triggers
- Local repo operations

## Setup

### 1. GitHub PAT

Create token with scopes: `repo`, `workflow`, `read:org`

### 2. Environment

```bash
export GITHUB_TOKEN="ghp_xxxxxxxxxxxx"
```

### 3. Global MCP Config

Add to `~/.claude/mcp.json`:

```json
{
  "mcpServers": {
    "github": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "${GITHUB_TOKEN}"
      }
    }
  }
}
```

### 4. CLI Auth

```bash
gh auth login
```

## Quick Reference

```bash
# Create PR
gh pr create --title "feat: thing" --body "description"

# Check PR status
gh pr checks

# Merge PR
gh pr merge --squash --delete-branch

# Run workflow
gh workflow run ci.yml

# View failed logs
gh run view --log-failed
```

---

## Review & Change History

**Current Version:** 0.1.0
**Review Status:** draft

### Changes Since Last Review
- Initial creation
