# Agent Context Registry — Session Handoff

**Date:** 2026-01-02
**Status:** Sandbox/Development (not live in any projects)
**Location:** `~/code/tools/agent-context-registry/`

---

## What This Is

Building infrastructure for AI-augmented development workflows. The **agent-context-registry** contains reusable primitives (agents, skills, tools, commands, prompts, policies) that can be symlinked into projects.

Part of larger **IPE (Intelligent Programming Environment)** effort — Stage 4: Workflow Configuration.

---

## Current Registry Structure

```
~/code/tools/agent-context-registry/
├── agents/
│   ├── nextjs-expert.md
│   ├── railway-expert.md
│   └── supabase-expert.md
├── commands/
│   ├── branch.md
│   ├── commit.md
│   ├── nextjs-debug.md
│   ├── pr.md
│   ├── railway-debug.md
│   ├── review.md (deprecated)
│   └── supabase-debug.md
├── docs/
│   ├── BUILTIN_COMMANDS_REFERENCE.md
│   ├── MCP_INVENTORY.md
│   └── PRIMITIVES.md
├── domains/
│   ├── NEXTJS.md
│   ├── RAILWAY.md
│   └── SUPABASE.md
├── plugins/
├── policies/
├── prompts/
│   ├── branch-name.md
│   ├── code-review.md
│   ├── commit-message.md
│   ├── documentation.md
│   ├── error-diagnosis.md
│   └── pr-description.md
├── skills/
│   ├── nextjs/
│   ├── railway/
│   └── supabase/
├── templates/
│   ├── mcp-base.json
│   └── PROJECT_INTEGRATION.md
├── tools/
│   ├── nextjs-cli.md
│   ├── railway-cli.md
│   ├── railway.md
│   └── supabase.md
├── README.md
└── REFERENCE.md
```

---

## Files Added This Session (Need Placement)

These were downloaded and copied by user. Verify they're in correct locations:

### Docs (→ `docs/`)
- `SKILL_CREATION_GUIDE.md` — Anthropic skill standard + AGS overlay
- `HIERARCHY_TIERS.md` — Global/Domain/Project tier definitions
- `REGISTRY_INVENTORY.md` — Complete inventory

### GitHub Domain Package (→ `domains/github/`)
Created but may need reorganization:
- `github-expert.md` → `domains/github/agents/github-expert.md`
- `github-SKILL.md` → `domains/github/skills/github/SKILL.md`
- `github.md` → `domains/github/tools/github.md`
- `github-debug.md` → `domains/github/commands/github-debug.md`
- `GITHUB.md` → `domains/github/GITHUB.md`

### Root
- `NEXT_SESSION.md` — Open questions and next steps

---

## AGS (Artifact Governance System)

Location: `~/code/tools/gov/`

Contains templates and user guide but **NO validation script exists**.

### AGS Frontmatter Schema

All registry files should have:
```yaml
---
doc_id: "type-XXX"        # Unique ID
slug: "kebab-case-name"   # URL-safe name
title: "Human Title"      # Display name
type: "agent|skill|tool|command|prompt|policy"
tier: "tier1|tier2|tier3"
status: "draft|active|deprecated|archived"
authority: "binding|guidance|informational"
version: "X.Y.Z"
review_status: "draft|pending|approved"
created: "YYYY-MM-DD"
updated: "YYYY-MM-DD"
owner: "human|agent-name"
depends_on: []
---
```

### Task: Create validate_ags.py

Script should:
1. Scan directory for .md files
2. Parse YAML frontmatter
3. Check required fields present
4. Validate field values against enums
5. Report errors/warnings

---

## Key Decisions Made

| Decision | Rationale |
|----------|-----------|
| Name: agent-context-registry | Descriptive, clear purpose |
| 6 primitive types | Agent, Skill, Tool, Command, Prompt, Policy |
| Anthropic skill format + AGS overlay | `name`/`description` for Claude + governance fields |
| Three-tier hierarchy | Global (every project), Domain (opt-in), Project (local) |
| GitHub is Global tier | Every project uses git |
| Symlink integration model | Projects link to registry, don't copy |

---

## Hierarchy Tiers

### Global (Every Project)
- MCP: Context7, Claude in Chrome, GitHub, Sequential Thinking
- Skills: code-review, commit-standards
- Prompts: commit-message, pr-description, branch-name

### Domain (Opt-In)
- Railway, Supabase, Next.js, GitHub, LangChain (future)
- Each domain = agent + skill + tool + commands

### Project (Local Only)
- Project-specific agents, custom workflows
- Not in registry — lives in project `.claude/`

---

## Open Questions

1. **claude-mem MCP** — What does it do? User has it connected.
2. **project-studio** — Early version of this work, Electron app. Park for now.
3. **claude-in-chrome** — Browser automation. Documented as global tier.
4. **Structure decision** — Keep flat or reorganize into domain-based hierarchy?

---

## Immediate Next Steps

1. **Verify file placement** — Check GitHub domain files landed correctly
2. **Create validate_ags.py** — Script to validate frontmatter
3. **Decide structure** — Flat vs domain-based organization
4. **Align skills to Anthropic format** — Add `name`/`description` to existing skills

---

## Context Files in Project Knowledge

These are in `/mnt/project/` (read-only):
- IPE_Product_Brief.md
- IPE_Artifact_Schema_Specification.md
- IPE_CLAUDE_Memory_Integration.md
- IPE_Stage_Navigation_v2.md
- ipe-research-synthesis.md
- Various stage specs and scaffolds

---

## Tool Access Notes

This session lost Filesystem tool access mid-conversation. Next session should verify:
```
Filesystem:list_allowed_directories
Filesystem:list_directory
Filesystem:read_file
Filesystem:write_file
```

If working, can directly manipulate `~/code/tools/agent-context-registry/`.

---

## Summary

**Built:** agent-context-registry with 3 complete domains (Railway, Supabase, Next.js) + GitHub domain package + reference docs + hierarchy definition.

**Status:** Sandbox only. Not integrated into any live projects.

**Next:** Validate structure, create AGS validation script, decide on flat vs domain-based organization.
