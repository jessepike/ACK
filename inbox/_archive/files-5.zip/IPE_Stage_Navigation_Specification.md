# IPE Stage Navigation - Design Specification

---

**Version:** 1.0  
**Created:** 2024-12-31  
**Status:** Design Complete

---

## Overview

Stage Navigation is the primary workflow control in IPE, allowing users to move between the 5 planning stages and track progress. Located in the top bar, it provides at-a-glance status of the entire planning lifecycle.

**Design Principles:**
- Clear visual hierarchy showing where you are
- Easy navigation between stages
- Progress tracking at stage and artifact level
- Non-linear access (can jump around stages)

---

## The 5 Stages

1. **Discovery** - Concept definition and validation research
2. **Solution Design** - Stack, architecture, data model, context schema
3. **Environment Setup** - Repo initialization, tooling, scaffolding
4. **Workflow Configuration** - Agent rules, dev workflow, operations
5. **Implementation Planning** - Phases, milestones, gates, tasks

**Flow:** Linear recommended, but non-linear allowed

---

## Layout & Position

### Top Bar Structure

```
┌──────────────────────────────────────────────────────────────┐
│ IPE-demo                                           User ⚙️   │
│                                                              │
│ [1. Discovery ✓ 4/4]  [2. Solution Design 2/4]  [3. Env...] │
│      ↑ Active              ↑ In Progress          ↑ Future  │
└──────────────────────────────────────────────────────────────┘
```

**Components:**
- **Left:** Project name
- **Center:** Stage tabs with progress
- **Right:** User profile, settings

**Height:** ~80px (accommodates project name + stage tabs)

---

## Stage Tab Design

### Tab Structure

```
┌──────────────────────────┐
│ 1. Discovery ✓ 4/4       │
│    ↑        ↑   ↑         │
│  Number   Check Count     │
└──────────────────────────┘
```

**Elements:**
- Stage number (1-5)
- Stage name
- Completion indicator (✓ when all artifacts complete)
- Artifact count (completed/total)

### Visual States

**Active Stage (Currently Working):**
```
[1. Discovery ✓ 4/4]
     Blue background
     White text
     Bold font
```

**Completed Stage:**
```
[1. Discovery ✓ 4/4]
     Green checkmark
     Gray background
     Standard font
     Clickable
```

**In Progress Stage:**
```
[2. Solution Design 2/4]
     Orange/amber indicator color for count
     Gray background
     Standard font
     Clickable
```

**Future/Not Started Stage:**
```
[3. Environment Setup 0/4]
     Light gray background
     Muted text
     Clickable (non-linear allowed)
```

**Locked Stage (Alternative - Not MVP):**
```
[5. Implementation Planning 🔒]
     Very light gray
     Lock icon
     Not clickable until previous complete
```
*Note: MVP allows jumping to any stage*

---

## Progress Indicators

### Artifact Count Badge

**Format:** `completed/total`

**Examples:**
- `0/4` - No artifacts started
- `2/4` - 2 of 4 artifacts finalized
- `4/4` - All artifacts complete (+ checkmark)

**Color Coding:**
- `0/X` - Red text
- `1-X/X` - Orange text (partial)
- `X/X` - Green text + ✓ checkmark

### Completion Checkmark

**When shown:** Only when `completed/total` equals 100%

**Visual:** Green ✓ before artifact count

```
✓ 4/4  (all complete)
  2/4  (incomplete)
```

---

## Stage Dropdown (Quick Navigation)

### Trigger

**Click stage tab** → Opens dropdown menu

```
┌────────────────────────────────────────────────┐
│ 1. Discovery ✓ 4/4 ▼                           │ ← Click to expand
└────────────────────────────────────────────────┘
```

### Dropdown Menu

```
┌──────────────────────────────────────┐
│ Discovery                        ✓   │
│ ├─ concept.md                    ✓   │ ← Click to jump to artifact
│ ├─ research.md                   ✓   │
│ ├─ validation.md                 ✓   │
│ ├─ scope.md                      ✓   │
│ └─ discovery-synthesis.md        ✓   │
│                                      │
│ [Complete Discovery Stage]           │ ← Action button
└──────────────────────────────────────┘
```

**Features:**
- Shows all artifacts in stage
- Checkmarks indicate finalized artifacts
- Click artifact to open in editor
- Stage completion button at bottom (when applicable)

**Alternative View (If stage not started):**

```
┌──────────────────────────────────────┐
│ Solution Design                      │
│ ├─ stack.md                          │
│ ├─ architecture.md                   │
│ ├─ data-model.md                     │
│ └─ context-schema.md                 │
│                                      │
│ [Start Solution Design]              │
└──────────────────────────────────────┘
```

---

## Navigation Behavior

### Clicking Stage Tab

**Active Stage:** Opens dropdown menu
**Other Stages:** Switches to that stage

**Result of switching:**
- Editor loads first artifact from new stage
- Left panel updates to show new stage artifacts
- URL updates (if applicable): `/project/stage-name`
- Preserve unsaved work with auto-save

### Clicking Artifact in Dropdown

**Behavior:**
- Switches to parent stage (if not already there)
- Opens selected artifact in editor
- Closes dropdown
- Scrolls to artifact in left panel (highlights it)

### Stage Progression

**Linear (Recommended):**
1. Complete Discovery
2. Unlock → Solution Design
3. Complete Solution Design
4. Unlock → Environment Setup
5. Etc.

**Non-Linear (MVP Allows):**
- Can click any stage at any time
- Useful for:
  - Reviewing earlier decisions
  - Working on multiple stages in parallel
  - Jumping ahead to plan future work

**Gate Warnings (Future Enhancement):**
```
┌────────────────────────────────────────┐
│ ⚠️  Warning                            │
│                                        │
│ Discovery stage is not complete.       │
│ Proceeding may result in rework.       │
│                                        │
│     [Go Back]  [Continue Anyway]       │
└────────────────────────────────────────┘
```

---

## Responsive Behavior

### Desktop (Wide Screen)

All 5 stages visible:
```
[1. Discovery ✓ 4/4] [2. Solution Design 2/4] [3. Environment...] [4. Workflow...] [5. Implementation...]
```

### Tablet/Narrow Desktop

Abbreviated stage names:
```
[1. Discovery ✓ 4/4] [2. Design 2/4] [3. Setup 0/4] [4. Config 0/0] [5. Plan 0/0]
```

### Mobile (Future)

Stage selector dropdown:
```
┌────────────────────────┐
│ Stage: Discovery ▼     │
└────────────────────────┘
```

---

## Stage-Specific Actions

### Discovery Stage

**Dropdown actions:**
```
[Generate Synthesis Document]
[Export for Review]
[Run Agent Validation]
[Complete Discovery Stage]
```

### Solution Design Stage

**Dropdown actions:**
```
[Generate Technical Spec Package]
[Review Architecture Decisions]
[Complete Solution Design]
```

### Environment Setup Stage

**Dropdown actions:**
```
[Initialize Repository]
[Install Dependencies]
[Generate Environment Manifest]
[Complete Environment Setup]
```

### Workflow Configuration Stage

**Dropdown actions:**
```
[Configure Agent Rules]
[Setup Workflows]
[Generate Playbook]
[Complete Workflow Config]
```

### Implementation Planning Stage

**Dropdown actions:**
```
[Generate Implementation Plan]
[Export to Project Management]
[Complete Planning]
[Start Development →]
```

---

## Color Scheme

### Stage Status Colors

**Active:**
- Background: `#007acc` (blue)
- Text: `#ffffff` (white)
- Border: `#0098ff` (lighter blue)

**Completed:**
- Background: `#2d2d2d` (dark gray)
- Text: `#e0e0e0` (light gray)
- Checkmark: `#4caf50` (green)
- Count: `#4caf50` (green)

**In Progress:**
- Background: `#2d2d2d` (dark gray)
- Text: `#e0e0e0` (light gray)
- Count: `#ff9800` (orange)

**Not Started:**
- Background: `#1e1e1e` (darker gray)
- Text: `#808080` (muted gray)
- Count: `#f44336` (red)

### Hover States

**Non-active tabs:**
- Background lightens by 5-10%
- Cursor changes to pointer
- Subtle scale animation (1.02x)

**Active tab:**
- No hover effect (already highlighted)
- Dropdown arrow appears/pulses

---

## Keyboard Navigation

### Stage Switching

- `Cmd/Ctrl + 1-5` - Jump to stage by number
- `Cmd/Ctrl + [` - Previous stage
- `Cmd/Ctrl + ]` - Next stage
- `Tab` (when in top bar) - Cycle through stages

### Dropdown

- `Space` or `Enter` on stage tab - Open dropdown
- `↑/↓` - Navigate artifacts in dropdown
- `Enter` - Select artifact
- `Esc` - Close dropdown

---

## Interaction Patterns

### Stage Switching Flow

**User clicks "Solution Design" from Discovery:**

1. Auto-save current work in Discovery
2. Close current artifact in editor
3. Update active stage highlight (blue)
4. Load Solution Design artifacts in left panel
5. Open first artifact (stack.md) in editor
6. Update URL/browser history
7. Animate transition (subtle fade)

**Duration:** ~200-300ms total

### First-Time Stage Entry

**When clicking a stage with 0/X artifacts:**

1. Show welcome modal (optional):
```
┌────────────────────────────────────────┐
│ Welcome to Solution Design             │
│                                        │
│ In this stage, you'll define:          │
│ • Technology stack                     │
│ • Architecture patterns                │
│ • Data model                           │
│ • Context schema                       │
│                                        │
│ All artifacts are pre-templated and    │
│ ready for you to complete.             │
│                                        │
│          [Get Started]                 │
└────────────────────────────────────────┘
```

2. Load stage with all artifacts visible
3. First artifact auto-expanded

---

## Progress Persistence

### Stage State Storage

**What gets saved:**
- Current active stage
- Artifact completion status per stage
- Stage completion status
- Last opened artifact per stage

**When:**
- On every stage switch
- On artifact finalization
- On stage completion

**Where:**
- Local project metadata file
- Synced to git (part of .ipe/ directory)

**Resume behavior:**
- Opening project loads last active stage
- Restores artifact states
- Preserves work-in-progress

---

## Stage Transitions & Gates

### Completing a Stage

**Checklist appears in dropdown:**
```
┌──────────────────────────────────────┐
│ Discovery Completion                 │
│                                      │
│ ✓ All artifacts finalized (4/4)     │
│ ✓ Synthesis document generated       │
│ ⚠ Agent validation pending           │
│                                      │
│   [Run Agent Validation]             │
└──────────────────────────────────────┘
```

**After validation passes:**
```
┌──────────────────────────────────────┐
│ Discovery Completion                 │
│                                      │
│ ✓ All artifacts finalized (4/4)     │
│ ✓ Synthesis document generated       │
│ ✓ Agent validation passed            │
│                                      │
│   [Complete Discovery Stage]         │
└──────────────────────────────────────┘
```

**On completion:**
- Stage marked as complete (green ✓)
- Next stage recommended/highlighted
- Optional celebration animation
- Source materials archived

### Gate Decision Points

**After stage completion, user can:**
1. **Proceed** → Move to next stage
2. **Prototype** → Create prototype to reduce uncertainty (Discovery only)
3. **Revise** → Unlock stage for changes (requires change order)

---

## Future Enhancements (Backlog)

### Visual Enhancements
- **Progress rings** - Circular progress around stage number
- **Stage thumbnails** - Visual preview of artifacts in dropdown
- **Timeline view** - Linear representation of all stages
- **Gantt chart** - Show stage dependencies and timeline

### Navigation
- **Stage search** - Quick jump to any artifact across all stages
- **Recent artifacts** - Quick access to recently edited
- **Favorites/bookmarks** - Pin frequently accessed artifacts
- **Breadcrumbs** - Stage > Artifact path in editor

### Collaboration
- **Multi-user indicators** - Show who's in which stage
- **Stage assignments** - Assign stages to team members
- **Stage comments** - Discussion threads at stage level
- **Stage approvals** - Require approval to complete stage

### Analytics
- **Time tracking** - How long in each stage
- **Completion velocity** - Artifacts completed per day
- **Bottleneck detection** - Where work slows down
- **Stage comparisons** - Compare projects' stage timelines

### Automation
- **Auto-advance** - Move to next stage when complete
- **Smart suggestions** - "Ready to move to Design?"
- **Parallel stages** - Work on multiple stages simultaneously
- **Stage templates** - Save common stage configurations

---

## Edge Cases

### Empty Project
- All stages show 0/X
- All clickable but show "Not Started" state
- First stage (Discovery) highlighted as suggested start

### Partially Complete Project
- Resume at last active stage
- Show mixed completion states
- Allow jumping to any stage

### Imported/Migrated Project
- Detect existing artifacts
- Auto-calculate completion counts
- Suggest validation run

### Corrupted State
- Fallback to stage 1 (Discovery)
- Warning message about state recovery
- Option to rebuild state from artifacts

---

## Technical Considerations

### State Management
- Global state for current stage
- Per-stage state for artifacts
- Persist to project metadata
- Sync across components

### Performance
- Lazy load stage artifacts
- Cache artifact metadata
- Debounce stage switches
- Optimize re-renders

### Accessibility
- ARIA labels for all stage tabs
- Keyboard navigation support
- Screen reader announcements on stage change
- Focus management in dropdown

---

## Success Metrics

**Usability:**
- Time to find specific artifact
- Stage switch errors (clicking wrong stage)
- Dropdown usage vs. direct stage clicks

**Workflow:**
- Average time per stage
- Stage completion rate
- Backtracking frequency (returning to earlier stages)

**Navigation:**
- Most common navigation paths
- Use of keyboard shortcuts
- Search/filter usage (if implemented)

---

**End of Stage Navigation Specification**
