# IPE Hook Scripts

**Location:** `.claude/hooks/`  
**Purpose:** Automate CLAUDE.md updates, state tracking, and validation  
**Stage:** 4 (Workflow Configuration)

---

## Overview

These hook scripts integrate with Claude Code's lifecycle to automate:
- CLAUDE.md context updates
- Implementation state tracking
- Stage finalization
- Repository structure validation
- Context injection at session start

**Hook Types:**
- **SessionStart** - Runs when Claude Code starts
- **Stop** - Runs when agent stops responding
- **SessionEnd** - Runs when session ends
- **PostToolUse** - Runs after tool execution

---

## Hook Scripts

| Script | Hook Event | Purpose |
|--------|------------|---------|
| `update-claude-md.sh` | Stop | Update CLAUDE.md active tasks section |
| `finalize-stage.sh` | SessionEnd | Mark stage as complete when done |
| `inject-stage-context.sh` | SessionStart | Load context at session start |
| `check-structure.sh` | PostToolUse | Validate file placement |
| `track-implementation.sh` | PostToolUse | Update state on file changes |
| `validate-claude-md.sh` | Manual | Validate CLAUDE.md structure |

---

## Installation

### 1. Create Hook Directory

```bash
mkdir -p .claude/hooks
cd .claude/hooks
```

### 2. Copy Hook Scripts

Copy all `.sh` files from this directory to `.claude/hooks/`

### 3. Make Scripts Executable

```bash
chmod +x .claude/hooks/*.sh
```

### 4. Configure Hooks in settings.json

```bash
# Edit settings
nano .claude/settings.json

# Or use the IPE helper
./scripts/configure-hooks.sh
```

**Add this configuration:**

```json
{
  "hooks": {
    "SessionStart": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "$CLAUDE_PROJECT_DIR/.claude/hooks/inject-stage-context.sh"
          }
        ]
      }
    ],
    "Stop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "$CLAUDE_PROJECT_DIR/.claude/hooks/update-claude-md.sh"
          }
        ]
      }
    ],
    "SessionEnd": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "$CLAUDE_PROJECT_DIR/.claude/hooks/finalize-stage.sh"
          }
        ]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "Write|Edit",
        "hooks": [
          {
            "type": "command",
            "command": "$CLAUDE_PROJECT_DIR/.claude/hooks/check-structure.sh"
          },
          {
            "type": "command",
            "command": "$CLAUDE_PROJECT_DIR/.claude/hooks/track-implementation.sh"
          }
        ]
      }
    ]
  }
}
```

### 5. Test Hooks

```bash
# Test each hook manually
./.claude/hooks/validate-claude-md.sh
./.claude/hooks/update-claude-md.sh
./.claude/hooks/check-structure.sh < test-input.json
```

---

## Hook Details

### update-claude-md.sh (Stop Hook)

**When:** Agent stops responding (task complete or pause)  
**Purpose:** Update "Active Context" section in CLAUDE.md

**Updates:**
- Current task from implementation-state.json
- Task progress counters
- Recent activity summary

**Input:** JSON via stdin (hook event data)  
**Output:** Updated CLAUDE.md

**Usage:**
```bash
# Manual trigger
./.claude/hooks/update-claude-md.sh

# Automatic (via Stop hook)
# Runs when agent finishes responding
```

---

### finalize-stage.sh (SessionEnd Hook)

**When:** Session ends  
**Purpose:** Mark stage as complete if all artifacts finalized

**Actions:**
1. Check if stage artifacts are finalized
2. Add completion marker to CLAUDE.md
3. Update static imports
4. Create stage summary

**Input:** JSON via stdin (session end data)  
**Output:** Updated CLAUDE.md, stage marker

**Usage:**
```bash
# Manual trigger
./.claude/hooks/finalize-stage.sh

# Automatic (via SessionEnd hook)
# Runs when Claude Code session ends
```

---

### inject-stage-context.sh (SessionStart Hook)

**When:** Session starts  
**Purpose:** Load context and display stage status

**Actions:**
1. Display current stage
2. Show recent progress
3. Inject claude-mem observations (if available)
4. Validate CLAUDE.md

**Input:** JSON via stdin (session start data)  
**Output:** Context messages to agent

**Usage:**
```bash
# Manual trigger
./.claude/hooks/inject-stage-context.sh

# Automatic (via SessionStart hook)
# Runs when Claude Code starts
```

---

### check-structure.sh (PostToolUse Hook)

**When:** After file Write/Edit operations  
**Purpose:** Validate file placement against repo-structure.md

**Checks:**
1. File created in allowed directory?
2. Follows naming conventions?
3. Tests mirror src structure?

**Input:** JSON via stdin (tool use data)  
**Output:** Exit code 0 (valid) or 2 (violation)

**Usage:**
```bash
# Manual trigger with test input
echo '{"tool_name":"Write","tool_input":{"file_path":"src/api/test.py"}}' | \
  ./.claude/hooks/check-structure.sh

# Automatic (via PostToolUse hook)
# Runs after every Write/Edit
```

---

### track-implementation.sh (PostToolUse Hook)

**When:** After file Write/Edit operations  
**Purpose:** Update implementation-state.json

**Updates:**
1. Files modified list
2. Last update timestamp
3. Current task state

**Input:** JSON via stdin (tool use data)  
**Output:** Updated implementation-state.json

**Usage:**
```bash
# Manual trigger with test input
echo '{"tool_name":"Write","tool_input":{"file_path":"src/main.py"}}' | \
  ./.claude/hooks/track-implementation.sh

# Automatic (via PostToolUse hook)
# Runs after every Write/Edit
```

---

### validate-claude-md.sh (Manual)

**When:** Run manually or via CI  
**Purpose:** Validate CLAUDE.md structure and content

**Checks:**
1. Required sections present
2. Token budget under limit
3. Imports reference existing files
4. No syntax errors

**Input:** None (reads CLAUDE.md)  
**Output:** Exit code 0 (valid) or 1 (invalid)

**Usage:**
```bash
# Validate current CLAUDE.md
./.claude/hooks/validate-claude-md.sh

# In CI/CD pipeline
if ! ./.claude/hooks/validate-claude-md.sh; then
  echo "CLAUDE.md validation failed"
  exit 1
fi
```

---

## Troubleshooting

### Hooks Not Running

**Symptoms:** No updates to CLAUDE.md, state not tracking

**Solutions:**
```bash
# 1. Check hooks are configured
cat .claude/settings.json | grep -A5 "hooks"

# 2. Verify scripts are executable
ls -la .claude/hooks/*.sh

# 3. Test hook manually
./.claude/hooks/update-claude-md.sh

# 4. Check Claude Code logs
tail -f ~/.claude/logs/claude-code.log
```

### Permission Errors

**Symptoms:** "Permission denied" when hooks run

**Solutions:**
```bash
# Make all scripts executable
chmod +x .claude/hooks/*.sh

# Check script ownership
ls -la .claude/hooks/

# Fix if needed
chown $USER .claude/hooks/*.sh
```

### JSON Parsing Errors

**Symptoms:** Hook fails with jq errors

**Solutions:**
```bash
# Verify jq is installed
which jq

# Install if missing
brew install jq  # macOS
sudo apt-get install jq  # Linux

# Test JSON parsing
echo '{"test":"value"}' | jq .
```

### CLAUDE.md Not Updating

**Symptoms:** Changes not appearing in CLAUDE.md

**Solutions:**
```bash
# 1. Check CLAUDE.md exists
ls -la .claude/CLAUDE.md

# 2. Verify file is writable
test -w .claude/CLAUDE.md && echo "Writable" || echo "Not writable"

# 3. Check for sed errors
./.claude/hooks/update-claude-md.sh 2>&1 | grep -i error

# 4. Run validation
./.claude/hooks/validate-claude-md.sh
```

---

## Testing Hooks

### Test Data

Create test input file:

```bash
cat > test-hook-input.json << 'EOF'
{
  "session_id": "test-123",
  "transcript_path": "/path/to/transcript.jsonl",
  "cwd": "/path/to/project",
  "permission_mode": "default",
  "hook_event_name": "PostToolUse",
  "tool_name": "Write",
  "tool_input": {
    "file_path": "src/api/test.py",
    "content": "test content"
  },
  "tool_use_id": "toolu_123"
}
EOF
```

### Test Each Hook

```bash
# Test structure check
cat test-hook-input.json | ./.claude/hooks/check-structure.sh
echo "Exit code: $?"

# Test state tracking
cat test-hook-input.json | ./.claude/hooks/track-implementation.sh
cat .ipe/implementation-state.json | jq .

# Test CLAUDE.md update
./.claude/hooks/update-claude-md.sh
git diff .claude/CLAUDE.md

# Test validation
./.claude/hooks/validate-claude-md.sh
```

---

## Development

### Adding New Hooks

1. Create script in `.claude/hooks/`
2. Make executable: `chmod +x script.sh`
3. Add shebang: `#!/bin/bash`
4. Parse JSON input: `input=$(cat)`
5. Add error handling
6. Test manually
7. Configure in settings.json

**Template:**

```bash
#!/bin/bash
# Hook: YourHookName
# Event: HookEventType
# Purpose: What this hook does

set -euo pipefail  # Exit on error

# Parse input
input=$(cat)

# Extract fields
field=$(echo "$input" | jq -r '.field_name')

# Your logic here
if [ condition ]; then
  # Do something
  exit 0
fi

# Error case
echo "Error message" >&2
exit 1
```

### Debugging Hooks

```bash
# Enable verbose output
set -x  # Add to top of script

# Log to file
exec > >(tee -a /tmp/hook-debug.log) 2>&1

# Print all variables
set | grep CLAUDE

# Test with debug mode
bash -x ./.claude/hooks/update-claude-md.sh
```

---

## Security Considerations

### File Permissions

Hooks have access to:
- Read/write CLAUDE.md
- Read/write implementation-state.json
- Read repo-structure.md
- Execute git commands

**Recommendations:**
- Keep hooks in `.claude/hooks/` only
- Don't give hooks network access
- Validate all JSON input
- Use `set -euo pipefail` for safety

### Input Validation

**Always validate:**
```bash
# Check input is JSON
if ! echo "$input" | jq . > /dev/null 2>&1; then
  echo "Invalid JSON input" >&2
  exit 1
fi

# Check required fields exist
if ! echo "$input" | jq -e '.required_field' > /dev/null; then
  echo "Missing required field" >&2
  exit 1
fi
```

---

## Environment Variables

**Available in hooks:**

| Variable | Description | Example |
|----------|-------------|---------|
| `CLAUDE_PROJECT_DIR` | Project root directory | `/Users/jess/projects/myapp` |
| `CLAUDE_ENV_FILE` | Env file for SessionStart | `/path/to/env` |
| `HOME` | User home directory | `/Users/jess` |
| `USER` | Current user | `jess` |

**Usage:**
```bash
# Use project-relative paths
STATE_FILE="$CLAUDE_PROJECT_DIR/.ipe/implementation-state.json"
CLAUDE_MD="$CLAUDE_PROJECT_DIR/.claude/CLAUDE.md"

# Avoid hardcoded paths
# ❌ STATE_FILE="/Users/jess/project/.ipe/state.json"
# ✅ STATE_FILE="$CLAUDE_PROJECT_DIR/.ipe/implementation-state.json"
```

---

## Maintenance

### Regular Tasks

**Weekly:**
- Review hook execution logs
- Check for errors in hook output
- Validate CLAUDE.md structure

**Monthly:**
- Update hook scripts if IPE spec changes
- Review hook performance
- Optimize slow hooks

**Per-Stage:**
- Update stage-specific logic
- Add new validations as needed
- Test hooks with new artifacts

### Version Control

**Commit hooks to git:**
```bash
git add .claude/hooks/*.sh
git add .claude/settings.json
git commit -m "Add IPE hook scripts for Stage 4"
```

**Don't commit:**
- Hook execution logs
- Debug output files
- Temporary test data

---

## Support

**Issues with hooks:**
1. Check this README first
2. Run validation scripts
3. Review Claude Code logs
4. Test hooks manually with sample input
5. Check settings.json configuration

**Common solutions:**
- Make scripts executable
- Verify jq is installed
- Check file paths are correct
- Ensure CLAUDE.md exists
- Validate JSON input format
