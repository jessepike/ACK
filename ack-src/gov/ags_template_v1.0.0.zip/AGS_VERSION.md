# AGS_VERSION.md

ags_version: "1.0.0"
released: "2026-01-01"
status: "stable"

Notes:
- v1.0.0 = first operational release (validator + derived registry + drift enforcement)
- System version is tracked via git tags (e.g., `ags-v1.0.0`) plus this file.
